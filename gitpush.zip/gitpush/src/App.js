import React from "react";
import Navbar from "./components/navbar/Navbar";
import Homepage from "./components/Homepage";
import LandingPage from "./components/LandingPage";
import LandingNext from "./components/LandingNext";
import AboutUs from "./components/AboutUs";
import EmergencyConversationPage from "./components/EmergencyContact";
import SocialMediaPage from "./components/SocialMedia";
import Headline from "./components/Headline";
import { useCustom } from "./components/useCustom";
// import ScrollingHeadline from "./components/ScrollingHeadline.jsx";

const App = () => {

  const [scrollLandingPage ,scrollLandingNext , scrollEmergencyConversationPage ,scrollAboutUs,scrollSocialMedia, handleSCroll] = useCustom();

  
    
  return (
    <div className="">
      <Navbar scrollLandingPage={scrollLandingPage} scrollLandingNext={scrollLandingNext} scrollEmergencyConversationPage={scrollEmergencyConversationPage}  scrollAboutUs={scrollAboutUs} scrollSocialMedia={scrollSocialMedia} handleSCroll={handleSCroll}/>
      <Headline />
      <Homepage   />
      <LandingPage  scrollLandingPage={scrollLandingPage} />
      <LandingNext  scrollLandingNext={scrollLandingNext} />
      <EmergencyConversationPage  scrollEmergencyConversationPage={scrollEmergencyConversationPage} />
      <AboutUs  scrollAboutUs={scrollAboutUs} />
      <SocialMediaPage  scrollSocialMedia={scrollSocialMedia} />
    </div>
  );
};

export default App;
