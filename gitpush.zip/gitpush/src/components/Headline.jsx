import React, { useState, useEffect } from 'react';

const Headline = () => {
  const [offset, setOffset] = useState(0);
  const [textWidth, setTextWidth] = useState(0);

  const headlineText = `यदि आपको कोई ऐसा व्यक्ति पता हो जो आत्महत्या करने की सोच रहा हो या मानसिक दबाव से पीड़ित है, तो कृपया हमारा विवरण उनके साथ साझा करें। If you know someone who is considering suicide or suffering from mental pressure, please share our details with them.`;

  useEffect(() => {
    const spanElement = document.getElementById('scrolling-text');
    if (spanElement) {
      setTextWidth(spanElement.offsetWidth);
    }
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setOffset(prevOffset => (prevOffset <= -textWidth ? 0 : prevOffset - 1));
    }, 12);

    return () => clearInterval(interval);
  }, [textWidth]);

  return (
    <div className="overflow-hidden bg-gray-200 rounded-md">
      <h1 className="text-xl font-bold text-center">
        <span
          id="scrolling-text"
          className="inline-block px-4 whitespace-nowrap"
          style={{ transform: `translateX(${offset}px)` }}
        >
          {headlineText + ' '}
          {headlineText + ' '}
          {headlineText + ' '}
          {headlineText + ' '}
          
        </span>
      </h1>
    </div>
  );
};

export default Headline;
