import React from 'react';

const AboutUs = ({scrollAboutUs}) => {
  return (
    // <div className="flex flex-wrap bg-cover min-h-screen bg-center h-64 md:h-full md:mt-0   md:mb-0 mb-[30%]" style={{ backgroundImage: "url('assets/autumn.jpg')" }}>
      
    <div ref={scrollAboutUs} className="flex flex-wrap bg-cover min-h-screen bg-center h-64 md:h-full md:mt-0 md:mb-0 mb-[30%] md:min-h-0" style={{ backgroundImage: "url('assets/autumn.jpg')" }}>

      
      
       {/* Right Side: Image */}
       <div className="md:w-[35%] md:w-1/2 p-8">
        <img
          src="assets/aboutUs.png"
          alt="Company"
          className="rounded-lg "
        />
      </div> 
      
      {/* Left Side: Text Content */}
      <div className="w-full md:w-1/2 p-8 ">
        <h2 className="text-3xl font-bold mb-4 text-center "><span className='bg-white rounded-lg p-1'>worthyyou're</span></h2>
        <p className="text-lg md:text-xl text-center bg-white font-helvetica rounded">
        worthyyou're, previously known as MindfulHeal, was established in 2016 by a distinguished psychiatrist and trailblazer in mental health care.

worthyyou're's core objective is to establish a comprehensive mental health ecosystem,
 offering tailored treatment plans and supportive interventions for a variety of mental
  health conditions, including anxiety, depression, bipolar disorder, attention deficit
   hyperactivity disorder (ADHD), obsessive-compulsive disorder (OCD)
, schizophrenia, and substance use disorders.
        </p>
      </div>

      
    </div>
  );
};

export default AboutUs;
