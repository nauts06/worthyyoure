import React from 'react';

const EmergencyConversationPage = ({scrollEmergencyConversationPage}) => {
  return (
    <div ref={scrollEmergencyConversationPage} className=" bg-cover bg-center md:mt-0 mt-[40%]  md:mb-0 mb-[0%]" style={{ backgroundImage: "url('assets/help.jpg')" }}>
      <div className="flex justify-center items-center h-full p-20">
        <div className="bg-white bg-opacity-75 p-8 rounded-lg shadow-lg">
          <h1 className="text-3xl font-bold mb-4 text-center">Emergency Conversation</h1>
          <p className="text-gray-700 text-center mb-4">If you need immediate assistance or emergency conversation with a psychologist, please contact us at:</p>
          <div className="flex items-center justify-center mb-4">
            <span className="text-lg font-semibold">Email: </span>
            <a href="mailto:yourpsychologist@example.com" className="text-blue-500 hover:underline">worthyyouare@gmail.com</a>
          </div>
          <p className="text-gray-700 text-center">We will respond to your email as soon as possible.</p>
        </div>
      </div>
    </div>
  );
};

export default EmergencyConversationPage;
