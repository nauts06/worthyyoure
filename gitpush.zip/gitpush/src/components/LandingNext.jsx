import React from 'react'

const LandingNext = ({scrollLandingNext}) => {
  return (
    <div ref={scrollLandingNext} className="bg-cover min-h-screen bg-center h-64 md:h-full" style={{ backgroundImage: "url('assets/imagewalltwo.jpg')" }}>

     <div className="flex flex-col items-center  ">
     <h1 className="text-3xl md:text-4xl font-bold mb-2 py-2  mt-10 bg-white rounded-lg text-gray-800 text-center font-helvetica mt-4">Personalized Counseling Solutions</h1>
        <p className="text-lg text-gray-500 bg-white mt-5 rounded-2xl p-1 text-center font-helvetica md:w-[60%]">
        Unified mental health platform, integrating diverse treatments for a seamless experience. We guide you from assessment to therapy, supporting every step of your journey.</p>
    </div>
    <div  className="w-[60%] flex flex-col  md:flex-row mt -2justify-center mt-8 max-w-screen-lg mx-auto bg-skyBlue rounded-lg items-center p-2 w-[90%]">
      <div className="md:w-1/2">
        <img src="assets/videocall.png" alt="Image" className="w-full h-auto md:rounded-l-lg" />
      </div>
      <div className="md:w-1/2 px-4 py-8 md:py-0">
        <p className="text-3xl md:text-4xl text-white text-center font-helvetica mb-4 ">Virtual Psychiatry Consultations</p>
        <p className="text-lg md:text-xl text-center text-white font-helvetica ">Access virtual psychiatry consultations for personalized mental health support from the comfort of home. Professional guidance available remotely, ensuring convenience and confidentiality.</p>
     
     
     
     
      </div>
    </div>
    </div>
  )
}

export default LandingNext