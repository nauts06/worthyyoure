import React, { useEffect, useState } from 'react'

const Homepage = () => {


  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);

  const slides = [
    // {
    //   title: 'समग्र मानसिक स्वास्थ्य समर्थन के लिए हमें विश्वास करें',
    //   content:
    //     'स्व-देखभाल, विशेषज्ञ चिकित्सा सहायता और समुदाय संसाधनों को एकत्रित करके व्यक्तिगत मानसिक स्वास्थ्य समर्थन को मुक्तिमान पूर्णतः आपकी आवश्यकताओं के लिए समायोजित करें।',
    //   buttonText: 'अपॉइंटमेंट बुक करें',
    // },
    {
      title: 'Confide us for Holistic Mental Health Support',
      content:'Combining Self-Care, Expert Therapeutic Assistance, and Community Resources for Personalized Mental Health Support That Fits Your Needs Perfectly',
      buttonText: 'Book Appointment',
    },
    // Add more slides if needed
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlideIndex((prevIndex) =>
        prevIndex === slides.length - 1 ? 0 : prevIndex + 1
      );
    }, 4000);

    return () => clearInterval(interval);
  }, []);
  return (
    <div  className="bg-cover bg-center h-64 md:h-full" style={{ backgroundImage: "url('assets/imagewallone.jpg')" }}>


<div className=" min-h-screen flex flex-col md:flex-row p-7">
    {/* Right Side */}
    <div className="md:w-1/2 md:order-2">
        <img className="object-cover w-full h-full" src="assets/clinical.png" alt="Illustration" />
      </div>
      {/* Left Side */}
      <div className="md:w-1/2 flex flex-col justify-center px-6 py-16 md:order-1">
      <h1 className="sm:text-gary-600 text-4xl md:text-5xl font-bold text-gray-800 mb-4 font-helvetica">
        {slides[currentSlideIndex].title}
      </h1>
      <p className="md:bg-white text-lg md:text-xl text-gray-600 mb-6 font-helvetica p-2 rounded-lg">
        {slides[currentSlideIndex].content}
      </p>
      <button className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded-full shadow-md transition duration-300 ease-in-out sm:w-[50%] mx-auto font-mono"
       onClick={() => {
        window.location.href = 'https://docs.google.com/forms/d/e/1FAIpQLSerJhK6aEIAxR3C3o6PyvnulYRFKYdt2JQxvRs2hpHxqrWf1Q/viewform?usp=sf_link' // Replace 'https://your-link.com' with the actual URL you want to redirect to
      }}
      
      >
 {slides[currentSlideIndex].buttonText} 
      </button>
    </div>
    </div>
    </div>
  )
}

export default Homepage

{/* <a href="https://docs.google.com/forms/d/e/1FAIpQLSerJhK6aEIAxR3C3o6PyvnulYRFKYdt2JQxvRs2hpHxqrWf1Q/viewform?usp=sf_link"> */}