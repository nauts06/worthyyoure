import React from 'react';

const SocialMediaPage = ({scrollSocialMedia}) => {
  return (
    <div ref={scrollSocialMedia} className="container mx-auto py-8  bg-cover bg-center w-full" style={{ backgroundImage: "url('assets/galaxy.jpg')" }}>
      <h1 className="text-3xl font-bold text-center mb-8 text-white" >Connect with Us</h1>
      <div className="flex flex-wrap justify-center">
        <div className="flex items-center mb-4 mr-4">
         <a href="https://www.instagram.com/worthyyoure/"><img src="assets/instagram.png" alt="Instagram" className="h-8 mr-2 cursor-pointer" /></a> 
         <a href="https://www.instagram.com/worthyyoure/">    <span className="text-lg font-semibold text-white cursor-pointer">Instagram</span></a>
        </div>
        <div className="flex items-center mb-4 mr-4">
          <img src="assets/fb.png" alt="Facebook" className="h-8 mr-2 cursor-pointer" />
          <span className="text-lg font-semibold text-white cursor-pointer">Facebook</span>
        </div>
        <div className="flex items-center mb-4 mr-4">
          <img src="assets/linkedin.png" alt="LinkedIn" className="h-8 mr-2 cursor-pointer" />
          <span className="text-lg font-semibold text-white cursor-pointer">LinkedIn</span>
        </div>  
        <div className="flex items-center mb-4 mr-4">
        <a href='https://wa.me/918516814771'> <img src="assets/whatsapp.png" alt="WhatsApp" className="h-8 mr-2 cursor-pointer" /></a> 
        <a href='https://wa.me/918516814771'> <span className="text-lg font-semibold text-white cursor-pointer">WhatsApp</span></a> 
        </div>
        <div className="flex items-center mb-4 mr-4">
          <img src="assets/youtube.png" alt="YouTube" className="h-8 mr-2 cursor-pointer" />
          <span className="text-lg font-semibold text-white cursor-pointer">YouTube</span>
        </div>
        <div className="flex items-center mb-4 mr-4">
          <img src="assets/telegram.png" alt="Telegram" className="h-8 mr-2 cursor-pointer" />
          <span className="text-lg font-semibold text-white cursor-pointer">Telegram</span>
        </div>
        <div className="flex items-center mb-4 mr-4">
          <img src="assets/X.png" alt="X" className="h-8 mr-2 cursor-pointer" />
          <span className="text-lg font-semibold text-white cursor-pointer">{"X (Twitter)"}</span>
        </div>
      </div>
    </div>
  );
};

export default SocialMediaPage;
