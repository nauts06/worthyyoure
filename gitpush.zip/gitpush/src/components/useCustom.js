import {  useRef } from "react";
export const useCustom = () => {
  const scrollAboutUs = useRef(null);
  const scrollSocialMedia = useRef(null);
  const scrollLandingPage = useRef(null);
  const scrollLandingNext = useRef(null);
  const scrollEmergencyConversationPage = useRef(null);

  const handleSCroll = (ref) => {
    console.log("ref", ref);
    ref.current.scrollIntoView();
  };

  return [scrollAboutUs,scrollSocialMedia, scrollLandingPage ,scrollLandingNext,scrollEmergencyConversationPage ,handleSCroll];
};
