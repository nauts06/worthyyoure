import React from 'react'

const LandingPage = ({scrollLandingPage}) => {
  return (
    <div ref={scrollLandingPage}>
    <div className="bg-tempColor min-h-screen flex flex-col justify-center items-center  sm:mt-0 mt-[129%]">
 
  {/* Top Headline */}
      <div className="text-center">
        <h1 className="text-3xl md:text-4xl font-bold mb-2 text-white font-helvetica mt-5">Why Us?</h1>
        <p className="text-lg text-white font-helvetica">Our platform is crafted by experienced psychiatrists, therapists, and mental health experts with vast global knowledge.</p>
    
    
      </div>
      
      {/* Boxes */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-8 w-full max-w-6xl">
        {/* Box 1 */}
        <div className="bg-white rounded-lg shadow-md p-6 flex flex-col items-center">
  <img className="w-24 h-12 mb-4" src="assets/expert.svg" alt="Icon 1" />
  <h2 className="text-xl font-bold mb-2 text-center font-helvetica">Expert Counseling Services</h2>
  <p className="text-gray-700 text-center font-helvetica">At our practice, we offer personalized counseling services tailored to your individual needs. Our experienced therapists provide compassionate support to help you navigate life's challenges.</p>
</div>

        {/* Box 2 */}
        <div className="bg-white rounded-lg shadow-md p-6 flex flex-col items-center">
  <img className="w-24 h-12 mb-4" src="assets/meditation.svg" alt="Icon 2" />
  <h2 className="text-xl font-bold mb-2 text-center font-helvetica">Mindfulness Meditation Sessions</h2>
  <p className="text-gray-700 text-center font-helvetica">Join our mindfulness meditation sessions to cultivate inner peace and enhance emotional well-being. Our certified instructors will guide you through various mindfulness techniques to promote relaxation and stress reduction.</p>
</div>

        {/* Box 2 */}
        <div className="bg-white rounded-lg shadow-md p-6 flex flex-col items-center">
  <img className="w-24 h-12 mb-4" src="assets/therapy.svg" alt="Icon 3" />
  <h2 className="text-xl font-bold mb-2 text-center font-helvetica">Cognitive Behavioral Therapy (CBT)</h2>
  <p className="text-gray-700 text-center font-helvetica">Experience the benefits of cognitive-behavioral therapy (CBT) in managing anxiety, depression, and other mental health issues. Our trained therapists will work with you to identify negative thought patterns and develop strategies for positive change.</p>
</div>


        {/* Box 2 */}
 <div className="bg-white rounded-lg shadow-md p-6 flex flex-col items-center">
  <img className="w-24 h-12 mb-4" src="assets/relationship.svg" alt="Icon 4" />
  <h2 className="text-xl font-bold mb-2 text-center font-helvetica">Family Counseling and Relationship Therapy</h2>
  <p className="text-gray-700 text-center font-helvetica">Our family counseling and relationship therapy services provide a safe space for open communication and conflict resolution. Whether you're facing marital issues, parent-child conflicts, or other family challenges, our therapists are here to help you rebuild and strengthen your relationships.</p>
</div>
     
      </div>
    </div>
{/* -----------------------next----------------- */}



<div>

</div>

    </div>
  )
}

export default LandingPage