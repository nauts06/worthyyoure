/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors:{
        tempColor : "rgb(64,168,197)",
        bgColor:"rgb(30,41,59)",
        skyBlue:"rgb(6,118,194)",
      },
      fontFamily: {
        cursive: ['cursive'],
        helvetica: ['Helvetica', 'Arial', 'sans-serif'],
      },
    },
  },
  plugins: [],
}